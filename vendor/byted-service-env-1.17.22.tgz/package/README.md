# @byted-service/env

[![bnpm](https://web-bnpm.byted.org/badge/v/@byted-service/env.svg?style=flat-square)](https://web-bnpm.byted.org/package/@byted-service/env) [![download](https://2y8ngapf.fn.bytedance.net/d?p=@byted-service/env)](https://web-bnpm.byted.org/package/@byted-service/env)

[简体中文](https://code.byted.org/nodejs/byted-service/blob/master/packages/env/README.md) | [English](https://code.byted.org/nodejs/byted-service/blob/master/packages/env/README.en.md) | [CHANGELOG](https://code.byted.org/nodejs/byted-service/blob/master/packages/env/CHANGELOG.md)

**@byted-service/env** 是公司内 `Node.js` 侧的基础环境变量 `SDK`，其在 `@byted-service/xxx` 中被广泛集成，主要数据来源有以下几个

-   [gopkg/env](https://code.byted.org/gopkg/env)
-   [TCE > TCE 的默认环境变量](https://bytedance.feishu.cn/wiki/wikcnR7f17phbl2h7ZVnj4KgRfg)
-   [FaaS > 系统默认环境变量说明](https://bytedance.feishu.cn/wiki/wikcndu0chhW1HyIZ0u4Puu7Cqh)
-   （TikTok专用）[tiktok/region_lib](https://code.byted.org/tiktok/region_lib) [文档](https://bytedance.feishu.cn/wiki/wikcn4YwQncW4hTDEfCQZEizo9c)

## 安装

```bash
npm install @byted-service/env --registry=http://bnpm.byted.org
```

## 快速开始

```ts
import { isProd } from '@byted-service/env';

isProd();
```

## API

### 运行环境

#### env.isProd()

是否是生产环境，与 `env.isProduct()` 相比，额外支持 `NODE_ENV` 环境变量

#### env.isTest()

是否是测试环境 ( `Boe` 环境同样认为是测试环境 )

#### env.isTesting()

Unknown

#### env.isBoe()

是否是 `Boe` 环境 ( `boe` + `boei18n` + `boexfl` + `boettp` )

#### env.isBoeCN()

是否是 `Boe` 环境 ( `boe` )

#### env.isBoeI18N()

是否是 `Boe` 环境 ( `boei18n` )

#### env.isBoeXfl()

是否是 `Boe` 环境 ( `boexfl` )

#### env.isBoeTTP()

是否是 `Boe` 环境 ( `boettp` )

#### env.isPPE()

是否是 `PPE` 环境

#### env.isEdgeEnvironment()

Unknown

#### env.isProduct()

是否是 `Prod` 环境

### PSM + Cluster + IDC + Env + Region + Stage + VDC + VRegion

#### env.getPSM()

服务 `PSM`

#### env.setPSM(psm)

设置服务 `PSM`

#### env.getCluster()

服务 `Cluster`

#### env.setCluster(cluster)

设置服务 `Cluster`.

#### env.getIDC()

服务 `IDC`

#### env.getIDCFromHost(ip)

从 `IP` 解析服务 `IDC`

Tips: `@byted-service/env` 初始化时，将会依次从以下文件中加载 `IDC` 网段解析数据

-   [/opt/tmp/consul_agent/netsegment](#opttmpconsul_agentnetsegment) ( `IPv4` )
-   [/opt/tiger/chadc/netsegment](#opttigerchadcnetsegment) ( `IPv4` )
-   [/opt/tmp/consul_agent/netsegment6](#opttmpconsul_agentnetsegment6) ( `IPv6` )
-   [/opt/tiger/chadc/netsegment6](#opttigerchadcnetsegment6) ( `IPv6` )

#### env.getIDCList()

服务 `IDC` 列表

#### env.setIDC(v)

设置服务 `IDC`

#### env.setIDCFile(file)

设置 `IDC` 网段解析文件 ( `IPv4` )

#### env.setIpv6File(file)

设置 `IDC` 网段解析文件 ( `IPv6` )

#### env.getEnv()

服务 `Env`，具体见 [基于 Env 的流量调度](https://bytedance.feishu.cn/docs/ws0Kg2Q539Rzqc18VFc98f)

#### env.isValidEnv()

校验服务 `Env` 是否合法，具体见 [Env 命名规范(定稿) > 具体细节](https://bytedance.feishu.cn/docs/doccn2zIJMueBhHi4kjrYKqaVYc#BTZPX3)

#### env.getRegion()

服务 `Region`

#### env.getRegionFromIDC(idc)

使用服务 `IDC` 换取服务 `Region`

Tips: `@byted-service/env` 初始化时，将会依次从以下文件中加载 `Region` 解析数据

-   [/opt/tiger/chadc/region.json](#opttigerchadcregionjson)

#### env.setRegionFile(file)

设置 `Region` 解析文件

#### env.getStage()

服务 `Stage`

#### env.getVRegionFromVDC(vdc)

使用服务 `VDC` 换取服务 `VRegion`

#### env.getCurrentVRegion()

服务 `VRegion`

#### env.getVRegionFromHost(ip)

从 `IP` 解析服务 `VRegion`

#### env.getGovernanceVRegionFromVDC(vdc)

使用服务 `VDC` 换取服务的真实服务治理 `VRegion`

### TikTok 的海外数据中心和区域信息，及相关判断函数

#### env.tt.VDC

TikTok 使用的 VDC 定义

#### env.tt.VREGION

TikTok 使用的 VREGION 定义

#### env.tt.VGEO

TikTok 使用的 VGEO 定义

#### env.tt.getVDC()

获取当前 vDC，非 TikTok 使用的环境会返回 env.tt.VDC.VDC_UNKNOWN ("-")

#### env.tt.getVRegion()

获取当前 vRegion，非 TikTok 使用的环境会返回 env.tt.VREGION.VREGION_UNKNOWN ("-")

#### env.tt.getVRegionFromVDC(vdc: string)

根据 vDC 获取 vRegion, 非 TikTok 使用的环境会返回 env.tt.VREGION.VREGION_UNKNOWN ("-")

#### env.tt.getVGeo()

获取当前 vGeo，非 TikTok 使用或者不属于任何 vGeo 的环境会返回 env.tt.VGEO.VGEO_UNKNOWN ("-")

#### env.tt.getVGeoFromVDC(vdc: string)

根据 vDC 获取 vGeo, 非 TikTok 使用或者不属于任何 vGeo 的环境会返回 env.tt.VGEO.VGEO_UNKNOWN ("-")

#### env.tt.getVGeoFromVRegion(vRegion: string)

根据 vRegion 获取 vGeo, 非 TikTok 使用或者不属于任何 vGeo 的环境会返回 env.tt.VGEO.VGEO_UNKNOWN ("-")

#### env.tt.isVGeoUS()

判断当前环境是否属于 US 的 vGeo

#### env.tt.isVGeoEU()

判断当前环境是否属于 US 的 vGeo

#### env.tt.isTexasRegion(regionCode: string)

判断一个 regionCode 是否属于 Project Texas

#### env.tt.isCloverRegion(regionCode: string)

判断一个 regionCode 是否属于 Project Clover

#### env.tt.isROWRegion(regionCode: string)

判断一个 regionCode 是否属于 ROW

#### env.tt.getComplianceRegion(regionCode: string)

判断一个 Region Code 的 ComplianceRegionType（ ROW | Texas | Clover | - ）

### env.tt.vdcToVregionMap

vdc 对应 vRegion 的映射

### env.tt.vRegionToVGeoMap

vRegion 对应 vGeo 的映射

### 机器 / 容器信息

#### env.getHostIP()

机器 / 容器 `IP` 地址，保留接口，为了兼容性优先返回 `IPv4`，其次是 `IPv6`

#### env.getHostIPV4()

机器 / 容器 `IPv4` 地址

#### env.getHostIPV6()

机器 / 容器 `IPv6` 地址

#### env.getIPv4()

机器 / 容器 `IPv4` 地址

#### env.getIPv6()

机器 / 容器 `IPv6` 地址

#### env.getIP()

机器 / 容器 `IP` 地址，优先返回 `IPv6`，其次是 `IPv4`

#### env.getIPStr()

同 [env.getIP()](#envgetip)

#### env.hasIPv4()

机器 / 容器是否存在 `IPv4` 地址

#### env.hasIPv6()

机器 / 容器是否存在 `IPv6` 地址

#### env.isDualStack()

机器 / 容器是否 `dual stack`，即同时存在 `IPv4` 与 `IPv6` 地址

#### env.isIPv4Only()

机器 / 容器是否 `IPv4 only`，即只存在 `IPv4` 地址

#### env.isIPv6Only()

机器 / 容器是否 `IPv6 only`，即只存在 `IPv6` 地址

#### env.getTCEServicePort()

`TCE` 平台上用户配置的 `primary` 端口

#### env.getTCEDebugPort()

`TCE` 平台上用户配置的 `debug` 端口

#### env.TCEServicePortRegistered()

返回 `TCE` 平台上用户配置的 `primary` 端口对应的访问端口

#### env.TCEDebugPortRegistered()

返回 `TCE` 平台上用户配置的 `debug` 端口对应的访问端口

#### env.isInTCE()

是否在 `TCE` 容器内

#### env.getPodName()

`TCE` 容器 `Pod` 名称

#### env.getImageVersion()

`TCE` 镜像 `tag`

#### env.getCloudEnv()

容器 `CloudEnv`

#### env.inVolcanoCloud()

是否在 `Volcano Cloud` 内

#### env.isHostNetwork()

网络模式是否为 host 或 autohost 模式

#### env.isCloudIDE()

是否是 Cloud IDE 环境

### Other

#### env.init()

初始化 `@byted-service/env`。默认情况下，所有 `API` 均有不同程度的缓存机制，因此，在修改环境变量之后，需要调用该方法重新初始化 `@byted-service/env`

#### env.defaultPSM

服务 `PSM` 默认值，默认 `-`

#### env.defaultCluster

服务 `Cluster` 默认值，默认 `default`

#### env.defaultIDC

服务 `IDC` 默认值，默认空字符串

#### env.defaultEnv

服务 `Env` 默认值，默认 `prod`

#### env.defaultStage

服务 `Stage` 默认值，默认 `-`

#### env.defaultPodName

容器 `Pod` 名称默认值，默认 `-`

#### env.defaultImageVersion

镜像 `tag` 默认值，默认 `-`

#### env.defaultCloudEnv

容器 `CloudEnv` 默认值，默认 `-`

#### env.PSMUnknown

#### env.ClusterDefault

#### env.IDC

已知服务 `IDC` 枚举

#### env.REGION

已知服务 `Region` 枚举

#### env.STAGE

已知服务 `Stage` 枚举

#### env.VDC

已知服务 `VDC` 枚举

#### env.VREGION

已知服务 `VRegion` 枚举

## 环境变量 / 配置文件

`@byted-service/env` 中使用到的环境变量如下

```sh
IS_TCE_DOCKER_ENV # 是否 TCE 容器环境
NODE_ENV # Node.js 专用环境变量，为 prod 或 production 时，代表是生产环境

LOAD_SERVICE_PSM # 服务 PSM
PSM # 同 LOAD_SERVICE_PSM，优先级更低
TCE_PSM # 同 PSM，优先级更低
SERVICE_CLUSTER # 服务 Cluster
RUNTIME_IDC_NAME # 服务 IDC
SERVICE_ENV # 服务 Env
TCE_ENV # 同 SERVICE_ENV，优先级更低
TCE_STAGE # 服务 Stage

MY_HOST_IP # 实例所在物理机的 IPv4
MY_HOST_IPV6 # 实例所在物理机的 IPv6
TCE_PRIMARY_PORT # TCE 平台上用户配置的 primary 端口
TCE_DEBUG_PORT # TCE 平台上用户配置的 debug 端口

IS_PROD_RUNTIME # 是否是 Prod 环境，已废弃
TESTING_PREFIX # Unknown
IS_EDGE_ENVIRONMENT # Unknown
TCE_HOST_ENV # TCE 控制面 Env
MY_POD_NAME # TCE 容器 Pod 名称
CURRENT_VERSION # TCE 镜像 tag
```

更多环境变量见

-   [TCE > TCE 的默认环境变量](https://bytedance.feishu.cn/wiki/wikcnR7f17phbl2h7ZVnj4KgRfg)
-   [FaaS > 系统默认环境变量说明](https://bytedance.feishu.cn/wiki/wikcndu0chhW1HyIZ0u4Puu7Cqh)

Tips: 部分变量采用的运行时注入，因此无法直接通过 `echo $XXX` 进行获取，可通过如下方法获得

```sh
ps -ef | grep node
# $pid 改为对应 Node.js 进程 pid
cat /proc/$pid/environ | tr "\0" "\n" | grep XXX
```

### /opt/tiger/chadc/netsegment

`IDC` 网段解析文件 ( `IPv4` )，具体见 [inf/chadc](https://code.byted.org/inf/chadc/blob/master/netsegment)

### /opt/tmp/consul_agent/netsegment

同 [/opt/tiger/chadc/netsegment](#opttigerchadcnetsegment)

### /opt/tiger/chadc/netsegment6

`IDC` 网段解析文件 ( `IPv6` )，具体见 [inf/chadc](https://code.byted.org/inf/chadc/blob/master/netsegment6)

### /opt/tmp/consul_agent/netsegment6

同 [/opt/tiger/chadc/netsegment6](#opttigerchadcnetsegment6)

### /opt/tiger/chadc/region.json

`Region` 解析文件，具体见 [inf/chadc](https://code.byted.org/inf/chadc/blob/master/region.json)

## 私有化部署 / DevBox

对于有私有化部署 / `DevBox` 需求的业务，可按照如下设置环境变量与文件

### Boe / BoeI18N

```sh
# 是否 TCE 容器环境
IS_TCE_DOCKER_ENV=1
# Node.js 专用环境变量
# NODE_ENV=test

# 服务 PSM
TCE_PSM=p.s.m
# 服务 Cluster
SERVICE_CLUSTER=default
# 服务 IDC ( boe 代表 Boe 环境，boei18n 代表 BoeI18N 环境 )
RUNTIME_IDC_NAME=boe
# 服务 Env ( 默认 prod，如果是泳道，则使用泳道名 )
SERVICE_ENV=prod
# 服务 Stage
# TCE_STAGE=single_dc

# 实例所在物理机的 IPv4
# MY_HOST_IP=127.0.0.1
# 实例所在物理机的 IPv6
# MY_HOST_IPV6=::
# TCE 平台上用户配置的 primary 端口
# TCE_PRIMARY_PORT=3000
# TCE 平台上用户配置的 debug 端口
# TCE_DEBUG_PORT=8080

# TCE 控制面 Env ( 固定值不可修改 )
TCE_HOST_ENV=boe
# TCE 容器 Pod 名称
# MY_POD_NAME=pod-xxx
# TCE 镜像 tag
# CURRENT_VERSION=123456
```

-   [/opt/tiger/chadc/netsegment](#opttigerchadcnetsegment): 可选，`IDC` 网段解析文件 ( `IPv4` )
    -   私有化部署: 需与运维同学确认是否存在该文件，如果不存在可自行添加
    -   `DevBox`: 默认会添加，如果文件较老，可重启 `DevBox` 或联系对应 `oncall`
-   [/opt/tiger/chadc/netsegment6](#opttigerchadcnetsegment6): 可选，`IDC` 网段解析文件 ( `IPv6` )
    -   私有化部署: 需与运维同学确认是否存在该文件，如果不存在可自行添加
    -   `DevBox`: 默认会添加，如果文件较老，可重启 `DevBox` 或联系对应 `oncall`
-   [/opt/tiger/chadc/region.json](#opttigerchadcregionjson): 可选，`Region` 解析文件
    -   私有化部署: 需与运维同学确认是否存在该文件，如果不存在可自行添加
    -   `DevBox`: 默认会添加，如果文件较老，可重启 `DevBox` 或联系对应 `oncall`

### PPE

```sh
# 是否 TCE 容器环境
IS_TCE_DOCKER_ENV=1
# Node.js 专用环境变量 ( PPE 环境与 Prod 环境一致，均为 prod )
# NODE_ENV=prod

# 服务 PSM
TCE_PSM=p.s.m
# 服务 Cluster
SERVICE_CLUSTER=default
# 服务 IDC ( lf 代表廊坊机房，可自行填写 )
RUNTIME_IDC_NAME=lf
# 服务 Env ( PPE 泳道名 )
SERVICE_ENV=ppe_xxx
# 服务 Stage
# TCE_STAGE=single_dc

# 实例所在物理机的 IPv4
# MY_HOST_IP=127.0.0.1
# 实例所在物理机的 IPv6
# MY_HOST_IPV6=::
# TCE 平台上用户配置的 primary 端口
# TCE_PRIMARY_PORT=3000
# TCE 平台上用户配置的 debug 端口
# TCE_DEBUG_PORT=8080

# TCE 控制面 Env ( 固定值不可修改 )
TCE_HOST_ENV=ppe
# TCE 容器 Pod 名称
# MY_POD_NAME=pod-xxx
# TCE 镜像 tag
# CURRENT_VERSION=123456
```

-   [/opt/tiger/chadc/netsegment](#opttigerchadcnetsegment): 可选，`IDC` 网段解析文件 ( `IPv4` )
    -   私有化部署: 需与运维同学确认是否存在该文件，如果不存在可自行添加
    -   `DevBox`: 默认会添加，如果文件较老，可重启 `DevBox` 或联系对应 `oncall`
-   [/opt/tiger/chadc/netsegment6](#opttigerchadcnetsegment6): 可选，`IDC` 网段解析文件 ( `IPv6` )
    -   私有化部署: 需与运维同学确认是否存在该文件，如果不存在可自行添加
    -   `DevBox`: 默认会添加，如果文件较老，可重启 `DevBox` 或联系对应 `oncall`
-   [/opt/tiger/chadc/region.json](#opttigerchadcregionjson): 可选，`Region` 解析文件
    -   私有化部署: 需与运维同学确认是否存在该文件，如果不存在可自行添加
    -   `DevBox`: 默认会添加，如果文件较老，可重启 `DevBox` 或联系对应 `oncall`

### Prod

```sh
# 是否 TCE 容器环境
IS_TCE_DOCKER_ENV=1
# Node.js 专用环境变量
# NODE_ENV=prod

# 服务 PSM
TCE_PSM=p.s.m
# 服务 Cluster
SERVICE_CLUSTER=default
# 服务 IDC ( lf 代表廊坊机房，可自行填写 )
RUNTIME_IDC_NAME=lf
# 服务 Env ( 固定值不可修改 )
SERVICE_ENV=prod
# 服务 Stage
# TCE_STAGE=single_dc

# 实例所在物理机的 IPv4
# MY_HOST_IP=127.0.0.1
# 实例所在物理机的 IPv6
# MY_HOST_IPV6=::
# TCE 平台上用户配置的 primary 端口
# TCE_PRIMARY_PORT=3000
# TCE 平台上用户配置的 debug 端口
# TCE_DEBUG_PORT=8080

# TCE 控制面 Env ( 固定值不可修改 )
# TCE_HOST_ENV=online
# TCE 容器 Pod 名称
# MY_POD_NAME=pod-xxx
# TCE 镜像 tag
# CURRENT_VERSION=123456
```

-   [/opt/tiger/chadc/netsegment](#opttigerchadcnetsegment): 可选，`IDC` 网段解析文件 ( `IPv4` )
    -   私有化部署: 需与运维同学确认是否存在该文件，如果不存在可自行添加
    -   `DevBox`: 默认会添加，如果文件较老，可重启 `DevBox` 或联系对应 `oncall`
-   [/opt/tiger/chadc/netsegment6](#opttigerchadcnetsegment6): 可选，`IDC` 网段解析文件 ( `IPv6` )
    -   私有化部署: 需与运维同学确认是否存在该文件，如果不存在可自行添加
    -   `DevBox`: 默认会添加，如果文件较老，可重启 `DevBox` 或联系对应 `oncall`
-   [/opt/tiger/chadc/region.json](#opttigerchadcregionjson): 可选，`Region` 解析文件
    -   私有化部署: 需与运维同学确认是否存在该文件，如果不存在可自行添加
    -   `DevBox`: 默认会添加，如果文件较老，可重启 `DevBox` 或联系对应 `oncall`

## 相关文档

-   [TCE > TCE 的默认环境变量](https://bytedance.feishu.cn/wiki/wikcnR7f17phbl2h7ZVnj4KgRfg)
-   [FaaS > 系统默认环境变量说明](https://bytedance.feishu.cn/wiki/wikcndu0chhW1HyIZ0u4Puu7Cqh)
-   [如何判断部署环境 > 服务端](https://bytedance.feishu.cn/wiki/wikcnmVz29FwukFO4Ux1Rtmc23c#sxJRso)
