# CHANGELOG

[![bnpm](https://web-bnpm.byted.org/badge/v/@byted-service/env.svg?style=flat-square)](https://web-bnpm.byted.org/package/@byted-service/env) [![download](https://2y8ngapf.fn.bytedance.net/d?p=@byted-service/env)](https://web-bnpm.byted.org/package/@byted-service/env)

[简体中文](https://code.byted.org/nodejs/byted-service/blob/master/packages/env/README.md) | [English](https://code.byted.org/nodejs/byted-service/blob/master/packages/env/README.en.md) | [CHANGELOG](https://code.byted.org/nodejs/byted-service/blob/master/packages/env/CHANGELOG.md)

## 1.17.22

chore: update vregion data

## 1.17.21

feat: generate vdc and vregion data from keel api

## 1.17.20

feat: add `sgcisa` IDC under `Asia-CIS` region.

feat: add new VRegion `Europe-WestBD`

## 1.17.19

feat: export `tt.getVRegionFromVDC(vdc: string)`, `tt.getVGeoFromVDC(vdc: string)` and `tt.getVGeoFromVRegion(vRegion: string)`

feat: export `tt.vRegionToVGeoMap` and `tt.vdcToVregionMap`

## 1.17.18

feat: add `my3` IDC under `Singapore-Central` region

## 1.17.17

fix: fix useast2b idc to region mapping for TT

## 1.17.16

feat: 新增 useast2b 机房 (Emerald/OCI-Emerald/OCI-New)，属于 US-EastRed 区域

## 1.17.15

fix: add `my4a` idc and `MY-Compliance` region

## 1.17.14

fix: 修复 idc to region mapping

## 1.17.13

fix: sync gopkg/env 的 region 数据

## 1.17.12

fix(env): 增加 mycisb idc and aisa-cis region

## 1.17.11

chore: update tslib version

## 1.17.10

fix(env): 增加 no1a 机房的 VRegion 映射

## 1.17.9

fix(env): 增加 no1a 机房以及对应 region 枚举

## 1.17.8

refactor(env): 新增 PIPO 合规 id1a/id2a/useast11a 机房和对应地域映射

## 1.17.7

refactor(env): 新增 useast10a 机房

## 1.17.6

refactor(env): 增加 Asia-SouthEastBD region 枚举和对应映射

## 1.17.5

fix(env): tt.getVRegion 新增 MY2 机房

## 1.17.4

fix(env): 新增 MY2 机房

## 1.17.3

fix(env): 修改 AsiaSinf-SouthEast 为 Asia-SouthEastBD

## 1.17.2

fix(env): 补充 boe2 和 mya 机房和 region 信息

## 1.17.1

fix(env): 修复 Tiktok VGeo 在 US-EastRed、boettp 环境下判断错误的问题

## 1.17.0

feat(env): 新增 env.isHostNetwork()、env.TCEServicePortRegistered()，新增 BOETTP/US-EastRed 机房判断

## 1.16.0

feat(env): add TikTok env help functions (more information in README)
feat(env): add typing for vregion
feat(env): add idc/region/vregion

## 1.15.2

feat(env): 增加 TTP2 Region

## 1.15.1

fix(env): 增加 MY idc

## 1.15.0

feat(env): 新增 env.isCloudIDE()

## 1.14.0

feat(env): 新增 env.isBoeTTP()

-   Commit: 10a015e17d90918e8c42b2f0e0ef7047634dd3bc

## 1.13.1

feat(env): 新增 idc、region、vregion

-   Commit: d4497a19b194cc1c8909bda52a2a6e3b6f1515b0

## 1.13.0

feat(env): 新增 env.isBoeXfl()

-   Commit: d2a77f151d48b9275d07031f3cbafa5827663762

## 1.12.3

fix(env): index.d.ts 导出问题

## 1.12.2

feat: 升级整体依赖版本

## 1.12.1

feat(env): 新增 idc、region、vregion、env.getCloudEnv()、env.inVolcanoCloud()

-   Commit: d07e5f925799910e0aa2e3d8ce37d8626463d302

## 1.12.0

feat(env): 新增 idc 与 region，并新增 version 模块

-   Commit: 15518d718080c985ccd1c4a6d0e8611b80309be8

## 1.11.1

feat(env): 新增 idc 与 region

-   Commit: 64736748ebf77665e8c5891058f393d01d870f5a

## 1.11.0

feat(env): 对齐 gopkg/env 实现

-   Commit: 46d5240c44e32c34d77523defcac940e0648c9d5
-   env.getIDC() 不支持 RUNTIME_ENV_IDC
-   env.getCluster() 不支持 TCE_CLUSTER

## 1.10.4

feat(env): 对齐 tce 部分的 api

## 1.10.3

feat(env): 更新默认配置，增加 ttp/oci 机房相关的默认配置; 处理 timer unref 的问题

## 1.10.2

feat(env): 兼容 HostIP

## 1.10.1

chore(env): getGatewayByEnv 在本地环境使用 127.0.0.1 替代硬编码的 10.17.91.134

## 1.10.0

feat(env): 同步 chadc 仓库的 region.json、netsegment、netsegment6 文件，更新 GCP 机房的 region-idc 兜底映射，[背景](https://bytedance.feishu.cn/docs/doccnglO2YuRZpxEbIhD1NOwVTb#z5HBF8)

## 1.9.3

fix(env): 发布文件包括 index.d.ts

## 1.9.2

fix(env): 去除 NODE_ENV 环境变量依赖

## 1.9.1

feat(env): 对齐 ip 与 env 部分的 api
fix(env): 修复导出类型定义问题

## 1.9.0

feat(env): 添加更新兜底数据的脚本; 增加 REGION 和 IDC 静态字段

## 1.8.0

feat(env): 升级 env，添加获取 getIPv6 和 getIPv4 的接口，去掉 isBoe 函数中通过 IP 判断当前机器所在机房的逻辑

## 1.7.2

fix(env): 修改 idc 默认值为 -

## 1.7.1

fix: 替换所有 lodash 为 lodash.xxx & 修复依赖检查脚本发现的 bug

## 1.7.0

feat(env): 增加 isFaas

## 1.6.1

feat(env): 增加 isPerfMode

## 1.6.0

feat(env): 增加 isBoeCN 和 isBoeI18N；更新代码中的默认 idc 配置。

## 1.5.2

增加`Mongo mesh`环境变量

## 1.5.1

增加`env.ipVersion` (获取当前容器支持的 ip 版本)

## 1.5.0

feat(env): 添加 PPE 环境判断和读取环境名 [Doc](https://bytedance.feishu.cn/docs/o70ApSpPCFk939zj5IclAc#UUdrOk)

## 1.4.15

feat(env): getIDC 支持 ipv6

## 1.4.14

fix(env): getGateway 中，确保执行`/sbin/ip route`时不会 throw
fix(env): 修复同步获取 region 数据时，没有正确设置 regionMap 的问题

## 1.4.13

feat(env): 更新 region 数据的获取机制

## 1.4.12@beta

feat(env): 更新获取 idc 数据的机制
