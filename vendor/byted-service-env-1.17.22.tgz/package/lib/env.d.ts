export declare const init: () => void;
/**
 * Env https://bytedance.feishu.cn/docs/ws0Kg2Q539Rzqc18VFc98f
 */
export declare const getEnv: () => string;
/**
 * IsValidEnv https://bytedance.feishu.cn/docs/doccn2zIJMueBhHi4kjrYKqaVYc#BTZPX3
 */
export declare const isValidEnv: (env: string) => boolean;
