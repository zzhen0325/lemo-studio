export declare const init: () => void;
/**
 * InTCE
 */
export declare const isInTCE: () => boolean;
/**
 * PodName
 */
export declare const getPodName: () => string;
/**
 * ImageVersion
 */
export declare const getImageVersion: () => string;
/**
 * CloudEnv
 */
export declare const getCloudEnv: () => string;
/**
 * InVolcanoCloud
 */
export declare const inVolcanoCloud: () => boolean;
/**
 * IsHostNetwork
 * 网络模式是否为 host 或 autohost 模式
 */
export declare const isHostNetwork: () => boolean;
