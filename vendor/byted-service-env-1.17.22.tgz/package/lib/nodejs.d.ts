export declare const defaultPSM = "-";
export declare const defaultCluster = "default";
export declare const defaultIDC = "";
export declare const defaultEnv = "prod";
export declare const defaultStage = "-";
export declare const defaultPodName = "-";
export declare const defaultImageVersion = "-";
export declare const defaultCloudEnv = "-";
export declare const init: () => void;
/**
 * 是否是 prod 环境，相比于 env.isProduct() 多支持了 NODE_ENV 环境变量
 */
export declare const isProd: () => boolean;
/**
 * 是否是 testing or boe 环境
 */
export declare const isTest: () => boolean;
