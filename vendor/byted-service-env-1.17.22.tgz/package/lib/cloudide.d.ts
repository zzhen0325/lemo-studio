export declare const init: () => void;
/**
 * 判断是否是 Cloud IDE 环境
 */
export declare const isCloudIDE: () => boolean;
