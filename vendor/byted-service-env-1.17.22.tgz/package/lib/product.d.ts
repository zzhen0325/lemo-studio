export declare const init: () => void;
/**
 * IsTesting if in testing env
 */
export declare const isTesting: () => boolean;
/**
 * IsBoe return true if it's in BOE by the IDC name
 */
export declare const isBoe: () => boolean;
/**
 * IsBoeCN return true if the idc is in China
 */
export declare const isBoeCN: () => boolean;
/**
 * IsBoeI18N return true if the idc is boei18n
 */
export declare const isBoeI18N: () => boolean;
/**
 * IsBoeTTP return true if the idc is boettp
 */
export declare const isBoeTTP: () => boolean;
/**
 * IsBoeXfl return true if the idc is volcano boexfl
 */
export declare const isBoeXfl: () => boolean;
export declare const isPPE: () => boolean;
export declare const isEdgeEnvironment: () => boolean;
/**
 * IsProduct return true if current service is running on product enviroment else false
 */
export declare const isProduct: () => boolean;
