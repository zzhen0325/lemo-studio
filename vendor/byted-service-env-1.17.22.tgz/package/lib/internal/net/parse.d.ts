/**
 * 以下来自 go 标准库 -> net/parse.go
 */
/**
 * Decimal to integer.
 * Returns number, characters consumed, success.
 */
export declare const dtoi: (s: string) => readonly [16777215, number, false] | readonly [0, 0, false] | readonly [number, number, true];
/**
 * Hexadecimal to integer.
 * Returns number, characters consumed, success.
 */
export declare const xtoi: (s: string) => readonly [number, number, true] | readonly [0, number, false];
