/**
 * 以下来自 go 标准库 -> net/ip.go
 */
export declare const IPv4len = 4;
export declare const IPv6len = 16;
export declare const v4InV6Prefix: number[];
/**
 * An IP is a single IP address, a slice of bytes.
 * Functions in this package accept either 4-byte (IPv4)
 * or 16-byte (IPv6) slices as input.
 *
 * Note that in this documentation, referring to an
 * IP address as an IPv4 address or an IPv6 address
 * is a semantic property of the address, not just the
 * length of the byte slice: a 16-byte slice can still
 * be an IPv4 address.
 */
export type IP = number[];
/**
 * An IPMask is a bitmask that can be used to manipulate
 * IP addresses for IP addressing and routing.
 *
 * See type IPNet and func ParseCIDR for details.
 */
type IPMask = number[];
export interface IPNet {
    IP: IP;
    Mask: IPMask;
}
/**
 * IPv4 returns the IP address (in 16-byte form) of the
 * IPv4 address a.b.c.d.
 */
export declare const IPv4: (a: number, b: number, c: number, d: number) => IP;
/**
 * CIDRMask returns an IPMask consisting of 'ones' 1 bits
 * followed by 0s up to a total length of 'bits' bits.
 * For a mask of this form, CIDRMask is the inverse of IPMask.Size.
 */
export declare const CIDRMask: (ones: number, bits: number) => IPMask;
/**
 * Mask returns the result of masking the IP address ip with mask.
 */
export declare const Mask: (ip: IP, mask: IPMask) => IP | null;
/**
 * Parse IPv4 address (d.d.d.d).
 */
export declare const parseIPv4: (s: string) => IP | null;
/**
 * parseIPv6 parses s as a literal IPv6 address described in RFC 4291
 * and RFC 5952.
 */
export declare const parseIPv6: (ss: string) => IP | null;
export declare const parseIP: (s: string) => IP | null;
/**
 * ParseCIDR parses s as a CIDR notation IP address and prefix length,
 * like "192.0.2.0/24" or "2001:db8::/32", as defined in
 * RFC 4632 and RFC 4291.
 *
 * It returns the IP address and the network implied by the IP and
 * prefix length.
 * For example, ParseCIDR("192.0.2.1/24") returns the IP address
 * 192.0.2.1 and the network 192.0.2.0/24.
 */
export declare const parseCIDR: (s: string) => readonly [undefined, undefined, Error] | readonly [IP, IPNet, null];
export {};
