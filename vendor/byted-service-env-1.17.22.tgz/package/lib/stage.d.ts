export declare const STAGE: {
    UnknownStage: string;
    StageStaging: string;
    StageCanary: string;
    StageSingleDC: string;
    StageAllDC: string;
};
export declare const init: () => void;
/**
 * Stage .
 */
export declare const getStage: () => string;
