export { IDC } from './idc_util';
export declare const init: () => void;
/**
 * IDC .
 */
export declare const getIDC: () => string;
/**
 * GetIDCFromHost .
 */
export declare const getIDCFromHost: (ip: string) => string;
/**
 * SetIDC .
 */
export declare const setIDC: (v: string) => void;
/**
 * SetIDCFile only replace file ipv4 segment
 */
export declare const setIDCFile: (file: string) => void;
/**
 * SetIpv6File only replace file ipv6 segment6
 */
export declare const setIpv6File: (file: string) => void;
