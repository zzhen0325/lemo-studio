export declare const REGION: {
    readonly UnknownRegion: "-";
    readonly R_CN: "CN";
    readonly R_SG: "SG";
    readonly R_US: "US";
    readonly R_MALIVA: "MALIVA";
    readonly R_ALISG: "ALISG";
    readonly R_CA: "CA";
    readonly R_BOE: "BOE";
    readonly R_ChinaBOE2: "China-BOE2";
    readonly R_SUITEKA: "SUITEKA";
    readonly R_SUITEKA2: "SUITEKA2";
    readonly R_SUITEKA3: "SUITEKA3";
    readonly R_YCRU: "YCRU";
    readonly R_I18N: "I18N";
    readonly R_USTTP: "US-TTP";
    readonly R_CNTOB: "CN-TOB";
    readonly R_USEast: "US-East";
    readonly R_USBOE: "US-BOE";
    readonly R_SingaporeCentral: "Singapore-Central";
    readonly R_AsiaSouth: "Asia-South";
    readonly R_AsiaSaaS: "Asia-SaaS";
    readonly R_EuropeCentral: "Europe-Central";
    readonly R_QMSG: "QMSG";
    readonly R_USTTP2: "US-TTP2";
    readonly R_USCentral: "US-Central";
    readonly R_EUTTP: "EU-TTP";
    readonly R_ChinaPay: "China-Pay";
    readonly R_ChinaVolcEast: "ChinaVolc-East";
    readonly R_ChinaVolcSouth: "ChinaVolc-South";
    readonly R_ChinaEast: "China-East";
    readonly R_EUCOMPLIANCE2: "EU-Compliance2";
    readonly R_EUCOMPLIANCE: "EU-Compliance";
    readonly R_IDCompliance: "ID-Compliance";
    readonly R_IDCompliance2: "ID-Compliance2";
    readonly R_USCompliance: "US-Compliance";
    readonly R_EUTTP2: "EU-TTP2";
    readonly R_ChinaPay2: "China-Pay2";
    readonly R_AsiaSouthEastBD: "Asia-SouthEastBD";
    readonly R_USEastBD: "US-EastBD";
    readonly R_IDCOMPLIANCE2: "ID-Compliance2";
    readonly R_IDCOMPLIANCE: "ID-Compliance";
    readonly R_USCOMPLIANCE: "US-Compliance";
    readonly R_AsiaCIS: "Asia-CIS";
    readonly R_MYCompliance: "MY-Compliance";
};
export declare const init: () => void;
/**
 * Region .
 */
export declare const getRegion: () => any;
/**
 * GetRegionFromIDC .
 */
export declare const getRegionFromIDC: (idc: string) => any;
/**
 * SetRegionFile .
 */
export declare const setRegionFile: (file: string) => void;
/**
 * hasIDC return true if idc is support
 */
export declare const hasIDC: (idc: string) => boolean;
/**
 * idcList return IDCs which supported
 */
export declare const idcList: () => string[];
/**
 * GetIDCList .
 */
export declare const getIDCList: () => string[];
