/** @deprecated use env.isInTCE() instead */
export declare const isDocker: () => boolean;
/** @deprecated please implement it yourself */
export declare const getGateway: () => string;
/** @deprecated please implement it yourself */
export declare const getGatewayByEnv: () => string;
/** @deprecated use env.getEnv() instead */
export declare const getPPEEnv: () => string;
/** @deprecated please implement it yourself */
export declare const isFaas: () => boolean;
/** @deprecated please implement it yourself */
export declare const isMysqlServiceMeshEnabled: () => boolean;
/** @deprecated please implement it yourself */
export declare const getMysqlServiceMeshAddr: () => string | undefined;
/** @deprecated please implement it yourself */
export declare const isMongoServiceMeshEnabled: () => boolean;
/** @deprecated please implement it yourself */
export declare const getMongoServiceMeshAddr: () => string | undefined;
/** @deprecated please implement it yourself */
export declare const isRPCServiceMeshEgressEnabled: () => boolean;
/** @deprecated please implement it yourself */
export declare const getRPCServiceMeshEgressAddr: () => string | undefined;
/** @deprecated please implement it yourself */
export declare const isRPCServiceMeshIngressEnabled: () => boolean;
/** @deprecated please implement it yourself */
export declare const isHTTPServiceMeshIngressEnabled: () => boolean;
/** @deprecated please implement it yourself */
export declare const getRPCServiceMeshIngressAddr: () => string | undefined;
/** @deprecated please implement it yourself */
export declare const isDpsAuthEnabled: () => boolean;
/** @deprecated use env.getEnv() instead */
export declare const getPodEnv: () => string;
/** @deprecated please implement it yourself */
export declare const getIPVersion: () => "" | "dual-stack" | "IPv6" | "IPv4";
/** @deprecated please implement it yourself */
export declare const getIPFamily: () => "" | "dual-stack" | "IPv6" | "IPv4";
/** @deprecated please implement it yourself */
export declare const isPerfMode: () => boolean;
