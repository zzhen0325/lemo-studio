export declare const init: () => void;
/**
 * HostIP 保留接口，为了兼容性优先返回 IPV4，其次是 IPV6
 */
export declare const getHostIP: () => string;
/**
 * HostIPV4 返回 ipv4 的 string
 */
export declare const getHostIPV4: () => string;
/**
 * HostIPV6 返回 ipv6 的 string
 */
export declare const getHostIPV6: () => string;
/**
 * IPV4 返回 ipv4
 */
export declare const getIPv4: () => string;
/**
 * IPV6 返回 ipv6
 */
export declare const getIPv6: () => string;
/**
 * IP 优先返回 IPV6，如果没有 IPV6 则返回 IPV4
 * 适用于 不在意获取到的是 IPV4 还是 IPV6 的业务
 */
export declare const getIP: () => string;
/**
 * IPStr 同上，返回 string
 */
export declare const getIPStr: () => string;
/**
 * HasIPV4
 */
export declare const hasIPv4: () => boolean;
/**
 * HasIPV6
 */
export declare const hasIPv6: () => boolean;
/**
 * IsDualStack
 */
export declare const isDualStack: () => boolean;
/**
 * IsIPV4Only
 */
export declare const isIPv4Only: () => boolean;
/**
 * IsIPV6Only
 */
export declare const isIPv6Only: () => boolean;
