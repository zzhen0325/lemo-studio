export declare const PSMUnknown = "-";
export declare const ClusterDefault = "default";
export declare const init: () => void;
/**
 * PSM .
 */
export declare const getPSM: () => string;
/**
 * SetPSM is used for unit test.
 */
export declare const setPSM: (psm_: string) => void;
/**
 * Cluster .
 */
export declare const getCluster: () => string;
/**
 * SetCluster is used for unit test.
 */
export declare const setCluster: (cluster_: string) => void;
