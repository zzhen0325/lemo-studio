export declare const init: () => void;
/**
 * TCEServicePort
 */
export declare const getTCEServicePort: () => string;
/**
 * TCEDebugPort
 */
export declare const getTCEDebugPort: () => string;
export declare const TCEServicePortRegistered: () => string;
export declare const TCEDebugPortRegistered: () => string;
export declare const TCEPortRegistered: (svr: string) => string;
