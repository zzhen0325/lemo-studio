import * as envApi from './env';
import * as idcApi from './idc';
import * as ipApi from './ip';
import * as portApi from './port';
import * as productApi from './product';
import * as regionApi from './region';
import * as serviceApi from './service';
import * as stageApi from './stage';
import * as tceApi from './tce';
import * as vregionApi from './vregion';
import * as nodejsApi from './nodejs';
import * as cloudIDEApi from './cloudide';
import * as deprecatedApi from './deprecated';
type EnvApi = Omit<typeof envApi, 'init'>;
type IdcApi = Omit<typeof idcApi, 'init'>;
type IpApi = Omit<typeof ipApi, 'init'>;
type PortApi = Omit<typeof portApi, 'init'>;
type ProductApi = Omit<typeof productApi, 'init'>;
type RegionApi = Omit<typeof regionApi, 'init' | 'hasIDC' | 'idcList'>;
type ServiceApi = Omit<typeof serviceApi, 'init'>;
type StageApi = Omit<typeof stageApi, 'init'>;
type TceApi = Omit<typeof tceApi, 'init'>;
type VregionApi = Omit<typeof vregionApi, 'init'>;
type NodejsApi = Omit<typeof nodejsApi, 'init'>;
type CloudIDEApi = Omit<typeof cloudIDEApi, 'init'>;
type DeprecatedApi = Omit<typeof deprecatedApi, 'init'> & {
    /** @deprecated use env.getPSM() instead */
    psm: string;
    /** @deprecated use env.getCluster() instead */
    cluster: string;
    /** @deprecated use env.getStage() instead */
    stage: string;
    /** @deprecated use env.getIDC() instead */
    idc: string;
    /** @deprecated use env.getIDCList() instead */
    idcList: string[];
    /** @deprecated use env.getRegion() instead */
    region: string;
    /** @deprecated use env.getIP() instead */
    ip: string;
    /** @deprecated use env.getIP() instead */
    hostIP: string;
    /** @deprecated use env.getPodName() instead */
    podName: string;
    /** @deprecated please implement it yourself */
    gateway: string;
    /** @deprecated please implement it yourself */
    gatewayByEnv: string;
    /** @deprecated use env.isInTCE() instead */
    kIsDocker: boolean;
    /** @deprecated please implement it yourself */
    kIsMysqlServiceMeshEnabled: boolean;
    /** @deprecated please implement it yourself */
    mysqlServiceMeshAddr?: string;
    /** @deprecated please implement it yourself */
    dpsAuthEnabled: boolean;
    /** @deprecated use env.getEnv() instead */
    podEnv: string;
    /** @deprecated use env.getEnv() instead */
    ppeENV: string;
    /** @deprecated please implement it yourself */
    ipVersion: string;
};
type Memorized<T extends {
    [key: string]: any;
}> = {
    [key in keyof T]: T[key] extends () => void ? (forceUpdate?: boolean) => ReturnType<T[key]> : T[key];
};
declare const env: EnvApi & IdcApi & IpApi & PortApi & ProductApi & RegionApi & ServiceApi & StageApi & TceApi & VregionApi & NodejsApi & CloudIDEApi & Omit<typeof deprecatedApi, "init"> & {
    /** @deprecated use env.getPSM() instead */
    psm: string;
    /** @deprecated use env.getCluster() instead */
    cluster: string;
    /** @deprecated use env.getStage() instead */
    stage: string;
    /** @deprecated use env.getIDC() instead */
    idc: string;
    /** @deprecated use env.getIDCList() instead */
    idcList: string[];
    /** @deprecated use env.getRegion() instead */
    region: string;
    /** @deprecated use env.getIP() instead */
    ip: string;
    /** @deprecated use env.getIP() instead */
    hostIP: string;
    /** @deprecated use env.getPodName() instead */
    podName: string;
    /** @deprecated please implement it yourself */
    gateway: string;
    /** @deprecated please implement it yourself */
    gatewayByEnv: string;
    /** @deprecated use env.isInTCE() instead */
    kIsDocker: boolean;
    /** @deprecated please implement it yourself */
    kIsMysqlServiceMeshEnabled: boolean;
    /** @deprecated please implement it yourself */
    mysqlServiceMeshAddr?: string | undefined;
    /** @deprecated please implement it yourself */
    dpsAuthEnabled: boolean;
    /** @deprecated use env.getEnv() instead */
    podEnv: string;
    /** @deprecated use env.getEnv() instead */
    ppeENV: string;
    /** @deprecated please implement it yourself */
    ipVersion: string;
} & Memorized<DeprecatedApi> & {
    /**
     * 初始化 @byted-service/env，用于需要动态加载环境变量的情况
     */
    init: () => void;
};
export default env;
