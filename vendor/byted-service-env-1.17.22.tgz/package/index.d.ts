import env from './lib/index';

export = env;
