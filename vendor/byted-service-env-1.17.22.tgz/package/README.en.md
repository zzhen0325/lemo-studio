# @byted-service/env

[![bnpm](https://web-bnpm.byted.org/badge/v/@byted-service/env.svg?style=flat-square)](https://web-bnpm.byted.org/package/@byted-service/env) [![download](https://2y8ngapf.fn.bytedance.net/d?p=@byted-service/env)](https://web-bnpm.byted.org/package/@byted-service/env)

[简体中文](https://code.byted.org/nodejs/byted-service/blob/master/packages/env/README.md) | [English](https://code.byted.org/nodejs/byted-service/blob/master/packages/env/README.en.md) | [CHANGELOG](https://code.byted.org/nodejs/byted-service/blob/master/packages/env/CHANGELOG.md)

**@byted-service/env** is the basic environment variable `SDK` on the `Node.js` side of the company. It is widely integrated in `@byted-service/xxx`. The main data sources are as follows:

-   [gopkg/env](https://code.byted.org/gopkg/env).
-   [TCE > Default Environment Variables of TCE](https://bytedance.feishu.cn/wiki/wikcnR7f17phbl2h7ZVnj4KgRfg).
-   [FaaS > System default environment variable description](https://bytedance.feishu.cn/wiki/wikcndu0chhW1HyIZ0u4Puu7Cqh).
-   (TikTok only) [tiktok/region_lib](https://code.byted.org/tiktok/region_lib) [Doc](https://bytedance.feishu.cn/wiki/wikcn4YwQncW4hTDEfCQZEizo9c).

## Installation

```bash
npm install @byted-service/env --registry=http://bnpm.byted.org
```

## Quick Start

```ts
import { isProd } from '@byted-service/env';

isProd();
```

## API

### Runtime Environment

#### env.isProd()

Whether it is production environment. Compared with `env.isProduct()`, it also supports `NODE_ENV`.

#### env.isTest()

Whether it is test environment ( `Boe` environment is also considered test environment ).

#### env.isTesting()

Unknown.

#### env.isBoe()

Whether it is `Boe` environment ( `boe` + `boei18n` + `boexfl` + `boettp` ).

#### env.isBoeCN()

Whether it is `Boe` environment ( `boe` ).

#### env.isBoeI18N()

Whether it is `Boe` environment ( `boei18n` ).

#### env.isBoeXfl()

Whether it is `Boe` environment ( `boexfl` )

#### env.isBoeTTP()

Whether it is `Boe` environment ( `boettp` )

#### env.isPPE()

Whether it is `PPE` environment.

#### env.isEdgeEnvironment()

Unknown.

#### env.isProduct()

Whether it is `Prod` environment.

### PSM + Cluster + IDC + Env + Region + Stage + VDC + VRegion

#### env.getPSM()

Service `PSM`.

#### env.setPSM(psm)

Set service `PSM`.

#### env.getCluster()

Service `Cluster`.

#### env.setCluster(cluster)

Set service `Cluster`.

#### env.getIDC()

Service `IDC`.

#### env.getIDCFromHost(ip)

Resolve service `IDC` from `IP`.

Tips: When `@byted-service/env` is initializing, it will load the data of the `IDC` network segment from the following files in sequence:

-   [/opt/tmp/consul_agent/netsegment](#opttmpconsul_agentnetsegment) ( `IPv4` )
-   [/opt/tiger/chadc/netsegment](#opttigerchadcnetsegment) ( `IPv4` )
-   [/opt/tmp/consul_agent/netsegment6](#opttmpconsul_agentnetsegment6) ( `IPv6` )
-   [/opt/tiger/chadc/netsegment6](#opttigerchadcnetsegment6) ( `IPv6` )

#### env.getIDCList()

Service `IDC` list.

#### env.setIDC(v)

Set service `IDC`.

#### env.setIDCFile(file)

Set `IDC` network segment file (`IPv4`).

#### env.setIpv6File(file)

Set `IDC` network segment file (`IPv6`).

#### env.getEnv()

Service `Env`, see [Env-based traffic scheduling](https://bytedance.feishu.cn/docs/ws0Kg2Q539Rzqc18VFc98f).

#### env.isValidEnv()

Check whether the service `Env` is valid, see [Env naming specification ( final ) > Specific details](https://bytedance.feishu.cn/docs/doccn2zIJMueBhHi4kjrYKqaVYc#BTZPX3).

#### env.getRegion()

Service `Region`.

#### env.getRegionFromIDC(idc)

Get service `Region` from service `IDC`.

Tips: When `@byted-service/env` is initializing, it will load the data of the `Region` from the following files in sequence:

-   [/opt/tiger/chadc/region.json](#opttigerchadcregionjson)

#### env.setRegionFile(file)

Set `Region` file.

#### env.getStage()

Service `Stage`.

#### env.getVRegionFromVDC(vdc)

Get service `VRegion` from service `VDC`.

#### env.getCurrentVRegion()

Service `VRegion`.

#### env.getVRegionFromHost(ip)

Resolve service `VRegion` from `IP`.

#### env.getGovernanceVRegionFromVDC(vdc)

Get service `VRegion` by real governace rules from service `VDC`.

### TikTok IDC/Region information and related helper functions

#### env.tt.VDC

definition of vDC used by TikTok

#### env.tt.VREGION

definition of vRegion used by TikTok

#### env.tt.VGEO

definition of vGeo used by TikTok

#### env.tt.getVDC()

get current vDC, environment not used by TikTok will return env.tt.VDC.VDC_UNKNOWN ("-")

#### env.tt.getVRegion()

get current vRegion, environment not used by TikTok will return env.tt.VREGION.VREGION_UNKNOWN ("-")

#### env.tt.getVRegionFromVDC(vdc: string)

get vRegion from vDC, vDC not used by TikTok will return env.tt.VREGION.VREGION_UNKNOWN ("-")

#### env.tt.getVGeo()

get current vGeo, environment not used  by TikTok or not belong to any vGeo will return env.tt.VGEO.VGEO_UNKNOWN ("-")

#### env.tt.getVGeoFromVDC(vdc: string)

get vGeo from vDC, vDC not used by TikTok or not belong to any vGeo will return env.tt.VGEO.VGEO_UNKNOWN ("-")

#### env.tt.getVGeoFromVRegion(vRegion: string)

get vGeo from vRegion, vRegion not used by TikTok or not belong to any vGeo will return env.tt.VGEO.VGEO_UNKNOWN ("-")

#### env.tt.isVGeoUS()

check current environment belongs to vGeo of US

#### env.tt.isVGeoEU()

check current environment belongs to vGeo of EU

#### env.tt.isTexasRegion(regionCode: string)

check regionCode belongs to Project Texas

#### env.tt.isCloverRegion(regionCode: string)

check regionCode belongs to  Project Clover

#### env.tt.isROWRegion(regionCode: string)

check regionCode belongs to  ROW

#### env.tt.getComplianceRegion(regionCode: string)

check Region Code ComplianceRegionType（ ROW | Texas | Clover | - ）

### env.tt.vdcToVregionMap

vDC to vRegion mapping

### env.tt.vRegionToVGeoMap

vRegion to vGeo mapping

### Machine / Container Information

#### env.getHostIP()

Machine / container `IP` address, compatibility interface, return `IPv4` first, followed by `IPv6`.

#### env.getHostIPV4()

Machine / container `IPv4` address.

#### env.getHostIPV6()

Machine / container `IPv6` address.

#### env.getIPv4()

Machine / container `IPv4` address.

#### env.getIPv6()

Machine / container `IPv6` address.

#### env.getIP()

Machine / container `IP` address, return `IPv6` first, followed by `IPv4`.

#### env.getIPStr()

See [env.getIP()](#envgetip).

#### env.hasIPv4()

Does the machine / container have an `IPv4` address.

#### env.hasIPv6()

Does the machine / container have an `IPv6` address.

#### env.isDualStack()

Whether the machine / container is `dual stack`, that is, there are both `IPv4` and `IPv6` addresses.

#### env.isIPv4Only()

Whether the machine / container is `IPv4 only`, that is, there are only `IPv4` addresses.

#### env.isIPv6Only()

Whether the machine / container is `IPv6 only`, that is, there are only `IPv6` addresses.

#### env.getTCEServicePort()

The `primary` port configured by the user on the `TCE` platform.

#### env.getTCEDebugPort()

The `debug` port configured by the user on the `TCE` platform.

#### env.TCEServicePortRegistered()

Return the access port corresponding to the `primary` port configured by the user on the `TCE` platform.

#### env.TCEDebugPortRegistered()

Return the access port corresponding to the `debug` port configured by the user on the `TCE` platform.

#### env.isInTCE()

Whether it is in the `TCE` container.

#### env.getPodName()

The `Pod` name of the `TCE` container.

#### env.getImageVersion()

The `tag` of `TCE` image.

#### env.getCloudEnv()

The `CloudEnv` of container,

#### env.inVolcanoCloud()

Whether it is in the `Volcano Cloud`.

#### env.isHostNetwork()

Whether the network mode set to host or autohost mode

#### env.isCloudIDE()

Is it a Cloud IDE environment.

### Other

#### env.init()

Initialize `@byted-service/env`. By default, all `API`s have different levels of caching mechanism. Therefore, after modifying environment variables, you need to call this method to reinitialize `@byted-service/env`.

#### env.defaultPSM

Service `PSM` default value, the value is `-`.

#### env.defaultCluster

Service `Cluster` default value, the value is `default`.

#### env.defaultIDC

Service `IDC` default value, the value is empty string.

#### env.defaultEnv

Service `Env` default value, the value is `prod`.

#### env.defaultStage

Service `Stage` default value, the value is `-`.

#### env.defaultPodName

Container `Pod` name default value, the value is `-`.

#### env.defaultImageVersion

Image `tag` default value, the value is `-`.

#### env.defaultCloudEnv

Container `CloudEnv` default value, the value is `-`.

#### env.PSMUnknown

#### env.ClusterDefault

#### env.IDC

Enumeration of known service `IDC`.

#### env.REGION

Enumeration of known service `Region`.

#### env.STAGE

Enumeration of known service `Stage`.

#### env.VDC

Enumeration of known service `VDC`.

#### env.VREGION

Enumeration of known service `VRegion`.

## Environment Variables / Configuration Files

The environment variables used in `@byted-service/env` are as follows:

```sh
IS_TCE_DOCKER_ENV # Whether it is TCE container environment.
NODE_ENV # Node.js only environment variable, when it is prod or production, it means the production environment.

LOAD_SERVICE_PSM # Service PSM.
PSM # Same as LOAD_SERVICE_PSM, but lower priority.
TCE_PSM # Same as PSM, but lower priority.
SERVICE_CLUSTER # Service Cluster.
RUNTIME_IDC_NAME # Service IDC.
SERVICE_ENV # Service Env.
TCE_ENV # Same as SERVICE_ENV, but lower priority.
TCE_STAGE # Service Stage.

MY_HOST_IP # IPv4 of the physical machine where the instance is located.
MY_HOST_IPV6 # IPv6 of the physical machine where the instance is located.
TCE_PRIMARY_PORT # The primary port configured by the user on the TCE platform.
TCE_DEBUG_PORT # The debug port configured by the user on the TCE platform.

IS_PROD_RUNTIME # Whether it is Prod environment. Deprecated.
TESTING_PREFIX # Unknown.
IS_EDGE_ENVIRONMENT # Unknown.
TCE_HOST_ENV # Env of the TCE control plane.
MY_POD_NAME # Pod name of TCE container.
CURRENT_VERSION # Tag of TCE image.
```

See more environment variables:

-   [TCE > Default Environment Variables of TCE](https://bytedance.feishu.cn/wiki/wikcnR7f17phbl2h7ZVnj4KgRfg).
-   [FaaS > System default environment variable description](https://bytedance.feishu.cn/wiki/wikcndu0chhW1HyIZ0u4Puu7Cqh).

Tips: Some variables are injected at runtime, so they cannot be obtained directly through `echo $XXX`, but can be obtained by the following.

```sh
ps -ef | grep node
# $pid changed to correspond to the Node.js process pid.
cat /proc/$pid/environ | tr "\0" "\n" | grep XXX
```

### /opt/tiger/chadc/netsegment

`IDC` network segment file ( `IPv4` ), see [inf/chadc](https://code.byted.org/inf/chadc/blob/master/netsegment).

### /opt/tmp/consul_agent/netsegment

See [/opt/tiger/chadc/netsegment](#opttigerchadcnetsegment).

### /opt/tiger/chadc/netsegment6

`IDC` network segment file ( `IPv6` ), see [inf/chadc](https://code.byted.org/inf/chadc/blob/master/netsegment6).

### /opt/tmp/consul_agent/netsegment6

See [/opt/tiger/chadc/netsegment6](#opttigerchadcnetsegment6).

### /opt/tiger/chadc/region.json

`Region` file, see [inf/chadc](https://code.byted.org/inf/chadc/blob/master/region.json).

## Privatization deployment / DevBox

For those who need privatization deployment / `DevBox`, you can set environment variables and files as follows.

### Boe / BoeI18N

```sh
# Whether it is TCE container environment.
IS_TCE_DOCKER_ENV=1
# Node.js only environment variable.
# NODE_ENV=test

# Service PSM.
TCE_PSM=p.s.m
# Service Cluster.
SERVICE_CLUSTER=default
# Service IDC ( boe means Boe environment, boei18n means BoeI18N environment ).
RUNTIME_IDC_NAME=boe
# Service Env ( the default value is prod, If it is a lane, use the lane name ).
SERVICE_ENV=prod
# Service Stage.
# TCE_STAGE=single_dc

# IPv4 of the physical machine where the instance is located.
# MY_HOST_IP=127.0.0.1
# IPv6 of the physical machine where the instance is located.
# MY_HOST_IPV6=::
# The primary port configured by the user on the TCE platform.
# TCE_PRIMARY_PORT=3000
# The debug port configured by the user on the TCE platform.
# TCE_DEBUG_PORT=8080

# Env of the TCE control plane ( fixed value cannot be modified ).
TCE_HOST_ENV=boe
# Pod name of TCE container.
# MY_POD_NAME=pod-xxx
# Tag of TCE image.
# CURRENT_VERSION=123456
```

-   [/opt/tiger/chadc/netsegment](#opttigerchadcnetsegment): Optional, `IDC` network segment file ( `IPv4` ).
    -   Privatization deployment: You need to confirm with SRE whether the file exists, if it does not exist, you can add it yourself.
    -   DevBox: It will be added by default, if the file is older, you can restart `DevBox` or contact `oncall`.
-   [/opt/tiger/chadc/netsegment6](#opttigerchadcnetsegment6): Optional, `IDC` network segment file ( `IPv6` ).
    -   Privatization deployment: You need to confirm with SRE whether the file exists, if it does not exist, you can add it yourself.
    -   DevBox: It will be added by default, if the file is older, you can restart `DevBox` or contact `oncall`.
-   [/opt/tiger/chadc/region.json](#opttigerchadcregionjson): Optional, `Region` file.
    -   Privatization deployment: You need to confirm with SRE whether the file exists, if it does not exist, you can add it yourself.
    -   DevBox: It will be added by default, if the file is older, you can restart `DevBox` or contact `oncall`.

### PPE

```sh
# Whether it is TCE container environment.
IS_TCE_DOCKER_ENV=1
# Node.js only environment variable ( the PPE environment is the same as the Prod environment, both are prod ).
# NODE_ENV=prod

# Service PSM.
TCE_PSM=p.s.m
# Service Cluster.
SERVICE_CLUSTER=default
# Service IDC ( lf means langfang machine room, you can fill in by yourself ).
RUNTIME_IDC_NAME=lf
# Service Env ( PPE plane name ).
SERVICE_ENV=ppe_xxx
# Service Stage.
# TCE_STAGE=single_dc

# IPv4 of the physical machine where the instance is located.
# MY_HOST_IP=127.0.0.1
# IPv6 of the physical machine where the instance is located.
# MY_HOST_IPV6=::
# The primary port configured by the user on the TCE platform.
# TCE_PRIMARY_PORT=3000
# The debug port configured by the user on the TCE platform.
# TCE_DEBUG_PORT=8080

# Env of the TCE control plane ( fixed value cannot be modified ).
TCE_HOST_ENV=ppe
# Pod name of TCE container.
# MY_POD_NAME=pod-xxx
# Tag of TCE image.
# CURRENT_VERSION=123456
```

-   [/opt/tiger/chadc/netsegment](#opttigerchadcnetsegment): Optional, `IDC` network segment file ( `IPv4` ).
    -   Privatization deployment: You need to confirm with SRE whether the file exists, if it does not exist, you can add it yourself.
    -   DevBox: It will be added by default, if the file is older, you can restart `DevBox` or contact `oncall`.
-   [/opt/tiger/chadc/netsegment6](#opttigerchadcnetsegment6): Optional, `IDC` network segment file ( `IPv6` ).
    -   Privatization deployment: You need to confirm with SRE whether the file exists, if it does not exist, you can add it yourself.
    -   DevBox: It will be added by default, if the file is older, you can restart `DevBox` or contact `oncall`.
-   [/opt/tiger/chadc/region.json](#opttigerchadcregionjson): Optional, `Region` file.
    -   Privatization deployment: You need to confirm with SRE whether the file exists, if it does not exist, you can add it yourself.
    -   DevBox: It will be added by default, if the file is older, you can restart `DevBox` or contact `oncall`.

### Prod

```sh
# Whether it is TCE container environment.
IS_TCE_DOCKER_ENV=1
# Node.js only environment variable.
# NODE_ENV=prod

# Service PSM.
TCE_PSM=p.s.m
# Service Cluster.
SERVICE_CLUSTER=default
# Service IDC ( lf means langfang machine room, you can fill in by yourself ).
RUNTIME_IDC_NAME=lf
# Service Env ( fixed value cannot be modified ).
SERVICE_ENV=prod
# Service Stage.
# TCE_STAGE=single_dc

# IPv4 of the physical machine where the instance is located.
# MY_HOST_IP=127.0.0.1
# IPv6 of the physical machine where the instance is located.
# MY_HOST_IPV6=::
# The primary port configured by the user on the TCE platform.
# TCE_PRIMARY_PORT=3000
# The debug port configured by the user on the TCE platform.
# TCE_DEBUG_PORT=8080

# Env of the TCE control plane ( fixed value cannot be modified ).
# TCE_HOST_ENV=online
# Pod name of TCE container.
# MY_POD_NAME=pod-xxx
# Tag of TCE image.
# CURRENT_VERSION=123456
```

-   [/opt/tiger/chadc/netsegment](#opttigerchadcnetsegment): Optional, `IDC` network segment file ( `IPv4` ).
    -   Privatization deployment: You need to confirm with SRE whether the file exists, if it does not exist, you can add it yourself.
    -   DevBox: It will be added by default, if the file is older, you can restart `DevBox` or contact `oncall`.
-   [/opt/tiger/chadc/netsegment6](#opttigerchadcnetsegment6): Optional, `IDC` network segment file ( `IPv6` ).
    -   Privatization deployment: You need to confirm with SRE whether the file exists, if it does not exist, you can add it yourself.
    -   DevBox: It will be added by default, if the file is older, you can restart `DevBox` or contact `oncall`.
-   [/opt/tiger/chadc/region.json](#opttigerchadcregionjson): Optional, `Region` file.
    -   Privatization deployment: You need to confirm with SRE whether the file exists, if it does not exist, you can add it yourself.
    -   DevBox: It will be added by default, if the file is older, you can restart `DevBox` or contact `oncall`.

## Documents

-   [TCE > Default Environment Variables of TCE](https://bytedance.feishu.cn/wiki/wikcnR7f17phbl2h7ZVnj4KgRfg).
-   [FaaS > System default environment variable description](https://bytedance.feishu.cn/wiki/wikcndu0chhW1HyIZ0u4Puu7Cqh).
-   [How to judge the deployment environment > Server](https://bytedance.feishu.cn/wiki/wikcnmVz29FwukFO4Ux1Rtmc23c#sxJRso).
