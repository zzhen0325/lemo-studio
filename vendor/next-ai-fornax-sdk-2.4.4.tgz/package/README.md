# @next-ai/fornax-sdk

[![bnpm](https://img.shields.io/badge/@next--ai/fornax--sdk-Fornax-544BFD?logo=ts-node&logoColor=white&style=flat-square)](https://web-bnpm.byted.org/package/@next-ai/fornax-sdk)
[![docs](https://img.shields.io/badge/SDK_Documentation-Fornax-544BFD?logo=googledocs&logoColor=white&style=flat-square)](https://bytedance.larkoffice.com/wiki/S3OOwqpRBiTdPBkdNLJcbSIjncc)

An AI Agent/Application development kit. Turn your ideas into code via:

## 🧩 AI Components

- Prompt Hub
  - `fornaxPromptHub`: Load and cache prompts from [Fornax](https://fornax.bytedance.net/). Supports batch preloading, variable interpolation (Jinja2/`{{var}}`), LRU caching with TTL, and integrated tracing.
- LLM Call: Provides a unified interface for LLM calls, smoothing out differences in message protocols and APIs across platforms.
  - `ptaas`: [Fornax](https://fornax.bytedance.net/) Prompt as a Service, with MCP supported.
  - `maas`: Doubao, Moonshot, GLM etc on [Ark](https://cloud.bytedance.net/ark).
  - `gpt`: Using OpenAI Completions API to access any compatible LLM (e.g., [ModelHub](https://gpt.bytedance.net/gpt_openapi/)).
  - `openai`: Using OpenAI Responses API (differs from `gpt` which uses Completions API)
  - `vllm`: Supports VLLM protocol for Merlin model invocation.

## ⛵️ AI Invocation

- `execute/streamExecute`: Invoke models, prompts, and auto tool calls in a simpler way.

## 🔭 Trace

- `fornaxTracer`: Initialize tracer, forceFlush, and manually start spans.
- `traceable`: Collect standardized trace data and report to Fornax observation module.

## 📌 Evaluation

- Evaluate agent/prompt/code with: Subjects, Datasets, Rules and Reporters.
- See 👉👉👉 [Fornax Node.js SDK 评测使用文档](https://bytedance.larkoffice.com/wiki/KsqJwcN4GiuCvjk6sxCc12XSnPh).

## 🪐 Open API

👉 [`@next-ai/fornax-api`](https://web-bnpm.byted.org/package/@next-ai/fornax-api)

## 🌰 Demo

> Code available in [flowdevops/fornax-oncall-agent](https://code.byted.org/flowdevops/fornax-oncall-agent)

**Fornax Oncall Agent** is a `ptaas + tool-calling` demo built with GuluX and `@next-ai/fornax-sdk`.

Try the following APIs:

- non-streaming: [`/agent/invoke`](https://imjzy6gq.fn.bytedance.net/agent/invoke?query=fornax%E5%B9%B3%E5%8F%B0%E6%98%AF%E5%B9%B2%E5%95%A5%E7%9A%84)
- streaming: [`/agent/stream`](https://imjzy6gq.fn.bytedance.net/agent/stream?query=fornax%E5%B9%B3%E5%8F%B0%E6%98%AF%E5%B9%B2%E5%95%A5%E7%9A%84)

## 🏠 Community

- [Fornax 用户交流3群](https://applink.larkoffice.com/client/chat/chatter/add_by_link?link_token=269qa147-c88e-4428-91ab-a708eceebaee)
- [Fornax 用户交流2群](https://applink.larkoffice.com/client/chat/chatter/add_by_link?link_token=68cnb27f-0f39-4115-92f3-07457262da76)
- [Fornax 用户群](https://applink.feishu.cn/client/chat/chatter/add_by_link?link_token=2b5odb18-5aca-40c5-a551-a51f518f47fe)
