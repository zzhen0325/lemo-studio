# 🕗 Change Log - @next-ai/fornax-sdk

## 2.4.4
>
> 2026-03-30

- [feat] `FORNAX_SDK_TELEMETRY` env control

## 2.4.3
>
> 2026-03-27

- [feat] add `input_cached_tokens` and `reasoning_tokens` in llm tags

## 2.4.2
>
> 2026-03-24

- [feat] add `cache_control` in content part for qwen models

## 2.4.1
>
> 2026-03-12

- [feat] add `onBeforeModelCall` hook in execute/streamExecute
- [feat] traceable `baggage`
- [feat] traceable `tagFilter`

## 2.4.0
>
> 2026-03-06

- [feat] migrate api service to `@next-ai/fornax-api`

## 2.3.18
>
> 2026-03-05

- [feat] support non-standard `reasoning_details` field
- [fix] non-standard `reasoning_details` field handling
- [fix] ptaas responses api issues

## 2.3.17
>
> 2026-02-09

- [feat] `reasoning_content` support in `gpt`, `maas`, `ptaas` model response and `execute/streamExecute`
- [fix] trace message `content` and `part` field handling
- [fix] reuse current tool call id in `gpt` stream mode
- [test] add stream tool call unit tests

## 2.3.16
>
> 2026-02-02

- [feat] `fornaxTracer` startSpan with `traceContext`

## 2.3.15
>
> 2026-01-30

- [feat] `fornaxPromptHub` cache (LRU + TTL)
- [feat] `fornaxPromptHub` get prompt with `releaseLabel`
- [chore] update default maas baseURL to `https://ark-cn-beijing.bytedance.net/api/v3`

## 2.3.14
>
> 2026-01-26

- [feat] prompt_version as rawInfo.id in `ptaas`
- [chore] deprecate StreamState and ReplyType in `ptaas`
- [chore] deprecate `fornaxRetriever`

## 2.3.13
>
> 2026-01-22

- [feat]: expand evaluator basic input type with `{ type: 'video'; url: string }`

## 2.3.12
>
> 2026-01-19

- [feat]: trace supports automatic reporting of the `psm_env` tag
- [feat]: the `gpt` module supports returning the non-standard `multimodal_contents` field
- [fix]: adjust the data retrieval method for `usage` and `finish_reason` in the stream call

## 2.3.11
>
> 2025-12-29

- [feat]: the `usage` field supplements the OpenAI SDK field
- [feat]: when passing a message, it supports the pass-through of the non-standard `reasoning_content` field to support some specific models

## 2.3.10
>
> 2025-12-18

- [feat]: add `file_url` message part

## 2.3.9
>
> 2025-12-17

- [fix]: otel NodeSDK.start() not setting global TracerProvider

## 2.3.8
>
> 2025-12-16

- [feat]: ptaas supports custom tool call configuration
- [feat]: add support for retrieving the ptaas response id
- [feat]: add pass-through support for the Gemini 3 Pro Preview `signature` field under ptaas

## 2.3.7
>
> 2025-12-04

- [feat]: compatible with gemini 3 pro toolcall
- [feat]: support ptaas responses api fields
- [fix]: ptaas trace in BOE env

## 2.3.6
>
> 2025-11-21

- [feat]: response_id in trace for `openai`

## 2.3.5
>
> 2025-11-19

- [feat]: support model video input

## 2.3.4
>
> 2025-11-18

- [feat]: llm component with logid

## 2.3.3
>
> 2025-11-17

- [feat]: `I18N_DEV` region of Fornax

## 2.3.2
>
> 2025-10-27

- [feat]: add raw_usage tag in openai
- [fix]: `fornaxPromptHub` render '' when var not found

## 2.3.1
>
> 2025-10-24

- [feat]: manual span via `fornaxTracer.startSpan`
- [fix]: `ptaas` call options (remove invalid responseFormat)

## 2.3.0
>
> 2025-10-20

- [feat]: upgrade openai to v5
- [feat]: add `openai` with [Responses API](https://platform.openai.com/docs/api-reference/responses) only, support
  - basic text generating
  - image input
  - new structured output
  - tool calling
  - response id

## 2.2.8
>
> 2025-09-26

- [feat]: `ptaas` with video parts in multi-part variables
- [fix]: `fornaxTracer` wrong format token report

## 2.2.7
>
> 2025-09-22

- Tracer
  - `fornaxTracer`: `traceContext` in `traceable` for distributed tracing

## 2.2.6
>
> 2025-09-16

- AI Components
  - `ptaas`: fix parts in stream

## 2.2.5
>
> 2025-09-12

- AI Components
  - `gpt`: support remote tool, like `tools: [{ type: 'google_search' }]`
  - `fornaxPromptHub`: set autoescape false on jinja2
- Others
  - GuluX esm compatiable

## 2.2.4
>
> 2025-09-10

- AI Components
  - `ptaas`: multi-parts variables

## 2.2.3
>
> 2025-09-04

- AI Components
  - `ptaas`: multi-parts response

## 2.2.2
>
> 2025-09-02

- AI Components
  - `gpt`, `maas`: set env `FORNAX_SDK_ENV` to `1` to enable debug logger
  - `ptaas`:
    - fix prompt empty object variable
    - `onRemoteToolCall` in stream mode (eg: prompt + MCP)

## 2.2.1
>
> 2025-08-26

- AI Components
  - `gpt`: compatible with `Gemini` tool call by fill empty tool call id

## 2.2.0
>
> 2025-08-25

- Feature
  - Tracer: replace ~~rpc~~ with http
    - fornaxTracer:
      - initialize: replace ~~initialize~~ with fornaxTracer.initialize
      - forceFlush: flush the current spans and report them
      - shutdown: forceFlush and then shutdown tracer
  - Fornax API Region: `I18N_VA` and `NON_TT`

## 2.1.10
>
> 2025-07-28

- AI Components
  - `fornaxPromptHub`: support jinja2 template

## 2.1.9
>
> 2025-07-08

- AI Components
  - `ptaas`, `fornaxPromptHub`: fornax prompt with message list
  - `gpt`: compatible with `Gemini` tool call (by removing $schema field)

## 2.1.8
>
> 2025-06-13

- AI Components
  - `fornaxPromptHub`, `fornaxRetriever`, `ptaas` http agent to support IPv6
- Fix:
  - `ptaas`: finish reason

## 2.1.7
>
> 2025-05-30

- AI Components
  - `ptaas`: MCP execute config (headers, params)
- Fix:
  - throw langchain wrapper error

## 2.1.6
>
> 2025-05-15

- Fix:
  - Tracer: Langchain model input, prompt hub output data

## 2.1.5
>
> 2025-04-25

- Tracer: inject sdk version

## 2.1.4
>
> 2025-04-21

- AI Components
  - `gpt`, `maas` and `vllm`: support `__extra` for model-specific parameters

## 2.1.3
>
> 2025-04-18

- AI Components
  - `ptaas`, `gpt`, `maas` and `vllm`: support timeout and signal in callOptions

## 2.1.2
>
> 2025-03-13

- AI Components
  - `fornaxRetriever`: add `startEmbedding`

## 2.1.1
>
> 2025-03-06

- Fix: typings

## 2.1.0
>
> 2025-03-05

- Fix
  - AI Components: `ptaas` params (internal)

## 2.0.9

> 2025-02-12

- Feature
  - AI Components
    - add `reasoningContent` which represents the thinking process of LLM
    - `gpt` and `maas` are compatiable with toolcall format of Doubao-pro-*

## 2.0.8

> 2025-02-07

- Feature
  - AI Components: `ptaas` supports `customModelConfig` (runtime model config)
  - Evaluation: add `fornaxDatasetLoader` which can fetch dataset on Fornax Platform
- Fix
  - AI Components: Missing logId

## 2.0.7

> 2024-12-30

- Feature
  - AI Components:
    - `fornaxPromptHub`: `listPrompts` to list prompts in Fornax space

## 2.0.6

> 2024-12-26

- Feature
  - Trace
    - Support automatic reporting of LangChain

## 2.0.5

> 2024-12-23

- Feature
  - Evaluation: Evaluate your agent or any code logic with `Evaluator`
    - see 👉 **[Fornax Node.js SDK 2.0 评测使用文档](https://bytedance.larkoffice.com/wiki/KsqJwcN4GiuCvjk6sxCc12XSnPh)** for more details
  - Service: `evaluationApi`, an open API for Fornax evaluation
    - `createEvaluationTask`
    - `pullDataset`
    - `insertToDataset`
    - `clearDataset`
  - AI Components
    - `fornaxRetriever`: Import data to knowledge table via `importTableData`
  - Trace
    - report tool call error
    - traceable error log

## 2.0.4

> 2024-12-06

- Feature
  - LLM Call
    - `vllm`: Support VLLM protocol, provide invocation of Merlin models.

## 2.0.3

> 2024-11-26

- Feature

  - `execute/streamExecute`: Support custom LogID
  - LLM Call
    - `gpt`: Support `baseURL` configuration
    - Add tool call callback function
    - Support `timeout` and `parallelToolCalls` configuration

- Fix
  - LLM Call
    - Pass-through LogID to downstream model service
    - Fix error when LLM returns choices as empty
    - Data structures compatible with `Claude` model

## 2.0.2

> 2024-11-08

- Feature
  - Support mixed content parts in message
  - `ptaas`: throw call errors

## 2.0.1

> 2024-11-05

- Feature
  - export missing type `ILLMCallStreamResults`

## 2.0.0

> 2024-11-01

😊 Initial version of fornax sdk.

- AI Components

  - Prompt Hub
    - `fornaxPromptHub`: Develop, submit and publish prompts on [Fornax](https://fornax.bytedance.net/), and load it via `fornaxPromptHub`
  - LLM Call
    - `ptaas`: [Fornax](https://fornax.bytedance.net/) Prompt as a Service
    - `maas`: Doubao, Moonshot, GLM etc on [Volcengine](https://console.volcengine.com/ark/region:ark+cn-beijing/endpoint)
    - `gpt`: Unified external LLMs access in ByteDance, see [Gpt OpenAPI](https://gpt.bytedance.net/gpt_openapi/)
  - RAG
    - `fornaxRetriever`: Upload Feishu/Lark documents on [Fornax](https://fornax.bytedance.net/) Knowledge Base, and retrieve releated knowledges.

- AI Ability Invocation

  - `execute/streamExecute`: Execute model, prompt and tool calls (auto) in a simpler way

- Trace
  - `tracer/traceable`: Collect standardized Trace data and report it to the observation module of the Fornax platform for consumption.
