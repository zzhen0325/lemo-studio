# @next-ai/fornax-api

[![bnpm](https://img.shields.io/badge/@next--ai/fornax--api-Fornax-544BFD?logo=ts-node&logoColor=white&style=flat-square)](https://web-bnpm.byted.org/package/@next-ai/fornax-api)

Open APIs of [✨ Fornax](https://fornax.bytedance.net/):

| Region      | Website                               | API Domain                             |
|-------------|---------------------------------------|----------------------------------------|
| CN          | <https://fornax.bytedance.net>        | <https://fornax.bytedance.net>         |
| I18N        | <https://fornax.byteintl.net>         | <https://fornax.byteintl.net>          |
| I18N_DEV    | <https://fornax-i18n.byteintl.net>    | <https://fornax-i18n.byteintl.net>     |
| I18N_VA     | <https://fornax.byteintl.net>         | <https://fornax-va.byteintl.net>       |
| NON_TT      | <https://fornax-i18nbd.byteintl.net>  | <https://fornax-i18nbd.byteintl.net>   |

## Available APIs

| API | Description |
|-----|-------------|
| `fornaxApi` | Fornax 空间管理相关接口 |
| `promptApi` | Prompt 平台相关接口 |
| `evaluationApi` | 评测 1.0 相关接口 |
| `evaluation2Api` | 评测 2.0 相关接口 |
| `knowledgeApi` | 知识库相关接口 |
| `observabilityApi` | 观测相关接口 |
| `datasetApi` | 数据集相关接口 |
| `skillApi` | Skill 相关接口 |

## How to

Example with `promptApi`:

```typescript
import { promptApi } from '@next-ai/fornax-api';

const api = promptApi({
  ak: 'fornax ak',
  sk: 'fornax sk',
  region: 'CN',
  // Custom headers
  // headers: {},
});

const resp = await api.MPullPrompt({
  prompt_queries: [
    { prompt_key: 'your.prompt.key' },
  ]
});

console.info(resp.prompts);
```

## References

- [OpenAPI 服务账号认证说明](https://bytedance.larkoffice.com/wiki/Dw4Ww4oeciqzcQk2vyVc8xo7nJ2)
- [空间权限开放接口说明](https://bytedance.larkoffice.com/wiki/RKCrwhxEdio1Lyk9dYMcTt2Anbe)
- [Prompt 开放接口说明](https://bytedance.larkoffice.com/wiki/JBoEwxPIfiBWRMkxTUEcRYhCnYe)
- [评测开放接口说明](https://bytedance.larkoffice.com/wiki/ISY2wAoJkiArockFuMHcM6mincf)
- [评测2.0 OpenAPI 使用手册](https://bytedance.larkoffice.com/wiki/Q04WwE2n8icfkhk7g5ucUk4Entc)
- [观测开放接口说明](https://bytedance.larkoffice.com/wiki/Sygrw8QmVi8Qp0kld3mcFXe4n8b)
- [数据集及其任务的开放接口说明](https://bytedance.larkoffice.com/wiki/SaVcw7l0Ziq8VtkXYdhcJtW3nob)

## API List
<!-- bam-api START -->
<!-- Last Update: Tue Mar 31 2026 16:11:12 GMT+0800 (China Standard Time) -->
### fornax-api
>
> PSM: `flow.devops.fornax`
>
> Version: `1.0.1831`

|API Name|API Path|Description|
|------|----------|----|
|`POST` AddSpaceMemberOApi|/open-apis/space_manage/v1/spaces/:space_id/add_members|空间角色添加授权|
|`POST` RemoveSpaceMemberOApi|/open-apis/space_manage/v1/spaces/:space_id/remove_members|空间角色删除授权|
|`POST` CreateSpaceOApi|/open-apis/space_manage/v1/spaces/create|↓↓↓空间对外开放接口↓↓↓创建空间 - 用于外部调用|

### prompt-api
>
> PSM: `flow.devops.prompt`
>
> Version: `1.0.467`

|API Name|API Path|Description|
|------|----------|----|
|`POST` Execute|/api/devops/prompt_platform/v1/prompt/execute|非流式调试运行|
|`POST` StreamingExecute|/api/devops/prompt_platform/v1/prompt/streaming_execute|流式调试运行|
|`POST` MPullPrompt|/api/devops/prompt_platform/v1/prompt/mpull|--------------- OpenAPI ---------------批量获取Prompt|
|`POST` ListPromptBasicOApi|/open-apis/prompt/v1/prompt/list|Prompt平台管理模块对外接口Prompt列表|

### skill-api
>
> PSM: `stone.cozeloop.prompt`
>
> Version: `1.0.251`

|API Name|API Path|Description|
|------|----------|----|
|`POST` BatchGetSkillsBySkillKey|/v1/loop/prompts/skills/batch_get|-|

### knowledge-api
>
> PSM: `flow.devops.knowledge`
>
> Version: `1.0.57`

|API Name|API Path|Description|
|------|----------|----|
|`POST` Retrieve|/api/devops/knowledge_platform/v1/retrieve|召回接口|
|`POST` ImportKnowledgeTableData|/open-apis/knowledge/v1/data/import_table_entry|OpenAPI接口|
|`POST` OApiStartEmbedding|/open-apis/knowledge/v1/embedding|-|
|`POST` OApiMGetKnowledgeShelfDocument|/open-apis/knowledge/v1/knowledge_shelf_doc/mget|-|
|`POST` OApiMGetKnowledgeDocumentEntry|/open-apis/knowledge/v1/knowledge_doc_entry/mget|-|
|`POST` OApiBatchDeleteKnowledgeDocumentEntry|/open-apis/knowledge/v1/knowledge_doc_entry/batch_delete|-|

### evaluation-api
>
> PSM: `flow.devops.evaluation`
>
> Version: `1.0.867`

|API Name|API Path|Description|
|------|----------|----|
|`POST` CreateCustomMetricsDataPoints|/open-api/evaluation/v1/cases/:case_id/tasks/:task_id/custom_metrics|-|
|`PUT` UpdateAgentOutput|/open-api/evaluation/v1/cases/:case_id/tasks/:task_id/row_group_results|-|
|`GET` ListTaskRowGroups|/open-api/evaluation/v1/cases/:case_id/tasks/:task_id/dataset/list|-|
|`PUT` CancelTasks|/open-api/evaluation/v1/cases/:case_id/tasks/cancel|-|
|`POST` CreateEvalTask|/open-api/evaluation/v1/cases/:case_id/tasks|-|
|`GET` GetAccountInfo|/open-api/evaluation/v1/account|-|
|`POST` BatchInsertRowGroups|/open-api/evaluation/v1/dataset/:dataset_id/row_groups|-|
|`POST` PullRowGroups|/open-api/evaluation/v1/dataset/:dataset_id/pull_row_groups|-|
|`POST` CreateEvalDataset|/open-api/evaluation/v1/dataset|-|
|`POST` ClearEvalDataset|/open-api/evaluation/v1/dataset/:dataset_id/clear|-|
|`POST` GetTaskResult|/open-api/evaluation/v1/cases/:case_id/tasks/:task_id/result|-|
|`GET` GetTaskInfo|/open-api/evaluation/v1/cases/:case_id/tasks/:task_id|-|

### evaluation2-api
>
> PSM: `stone.cozeloop.evaluation`
>
> Version: `1.0.555`

|API Name|API Path|Description|
|------|----------|----|
|`POST` ReportEvalTargetInvokeResult|/open-api/evaluation/v1/eval_targets/result|评测目标调用结果上报接口|
|`POST` CreateEvaluatorOApi|/v1/loop/evaluation/evaluators|创建评估器|
|`POST` CreateEvaluationSetVersionOApi|/open-api/evaluation/v1/evaluation_sets/:evaluation_set_id/versions|创建评测集版本|
|`POST` SubmitExperimentOApi|/open-api/evaluation/v1/experiments|评测实验接口创建评测实验|
|`GET` GetEvaluationSetOApi|/open-api/evaluation/v1/evaluation_sets/:evaluation_set_id|获取评测集详情|
|`PUT` BatchUpdateEvaluationSetItemsOApi|/open-api/evaluation/v1/evaluation_sets/:evaluation_set_id/items|批量更新评测集数据|
|`POST` BatchCreateEvaluationSetItemsOApi|/open-api/evaluation/v1/evaluation_sets/:evaluation_set_id/items|批量添加评测集数据|
|`POST` CreateEvaluationSetOApi|/open-api/evaluation/v1/evaluation_sets|评测集接口创建评测集|
|`GET` ListEvaluationSetsOApi|/open-api/evaluation/v1/evaluation_sets|查询评测集列表|
|`GET` ListEvaluationSetVersionItemsOApi|/open-api/evaluation/v1/evaluation_sets/:evaluation_set_id/items|查询评测集特定版本数据|
|`PUT` UpdateEvaluationSetSchemaOApi|/open-api/evaluation/v1/evaluation_sets/:evaluation_set_id/schema|更新评测集字段信息|
|`GET` ListEvaluationSetVersionsOApi|/open-api/evaluation/v1/evaluation_sets/:evaluation_set_id/versions|获取评测集版本列表|
|`POST` GetExperimentAggrResultOApi|/open-api/evaluation/v1/experiments/:experiment_id/aggr_results|获取聚合结果|
|`POST` ListExperimentResultOApi|/open-api/evaluation/v1/experiments/:experiment_id/results|查询评测实验结果|
|`GET` GetExperimentsOApi|/open-api/evaluation/v1/experiments/:experiment_id|获取评测实验|
|`DELETE` DeleteEvaluationSetOApi|/open-api/evaluation/v1/evaluation_sets/:evaluation_set_id|删除评测集|
|`POST` BatchGetEvaluatorVersionsOApi|/v1/loop/evaluation/evaluators_versions/batch_get|批量查询评估器版本|
|`PATCH` UpdateEvaluatorOApi|/v1/loop/evaluation/evaluators/:evaluator_id|更新评估器|
|`DELETE` DeleteEvaluatorOApi|/v1/loop/evaluation/evaluators/:evaluator_id|删除评估器|
|`POST` SubmitEvaluatorVersionOApi|/v1/loop/evaluation/evaluators/:evaluator_id/submit_version|提交评估器版本|
|`POST` ListEvaluatorsOApi|/v1/loop/evaluation/evaluators/list|评估器接口查询评估器列表|
|`POST` BatchGetEvaluatorsOApi|/v1/loop/evaluation/evaluators/batch_get|批量查询评估器|
|`PATCH` CorrectEvaluatorRecordOApi|/v1/loop/evaluation/evaluator_records/:evaluator_record_id|修正评估记录|
|`POST` RunEvaluatorOApi|/v1/loop/evaluation/evaluators_versions/:evaluator_version_id/run|执行评估器|
|`POST` BatchGetEvaluatorRecordsOApi|/v1/loop/evaluation/evaluator_records/batch_get|批量查询评估记录|
|`POST` ListEvaluatorVersionsOApi|/v1/loop/evaluation/evaluators/:evaluator_id/versions/list|查询评估器版本列表|
|`PATCH` UpdateEvaluatorDraftOApi|/v1/loop/evaluation/evaluators/:evaluator_id/update_draft|更新评估器草稿|

### observability-api
>
> PSM: `stone.cozeloop.observability`
>
> Version: `1.0.246`

|API Name|API Path|Description|
|------|----------|----|
|`POST` IngestTraces|/open-api/observability/traces/ingest|-|
|`POST` ListSpansOApi|/open-api/observability/spans/search|-|
|`POST` SearchTraceOApi|/open-api/observability/traces/search|-|
|`POST` CreateAnnotation|/open-api/observability/annotations|-|
|`DELETE` DeleteAnnotation|/open-api/observability/annotations|-|

### dataset-api
>
> PSM: `stone.fornax.ml_flow`
>
> Version: `1.0.1568`

|API Name|API Path|Description|
|------|----------|----|
|`POST` OpenBatchGetDatasetItemsByVersion|/open-api/ml_flow/v2/datasets/:datasetID/versions/:versionID/items/batch_get|批量获取固定版本数据行|
|`GET` OpenListDatasetItems|/open-api/ml_flow/v2/datasets/:datasetID/items|草稿态的数据行列表|
|`PATCH` OpenPatchDatasetItem|/open-api/ml_flow/v2/datasets/:datasetID/items/:itemID|更新数据行的数据内容|
|`POST` OpenBatchGetDatasetItems|/open-api/ml_flow/v2/datasets/:datasetID/items/batch_get|批量获取草稿态数据行|
|`POST` OpenBatchDeleteDatasetItems|/open-api/ml_flow/v2/datasets/:datasetID/items/batch_delete|批量删除草稿态数据行|
|`POST` OpenCreateDatasetVersion|/open-api/ml_flow/v2/datasets/:datasetID/versions|创建数据集版本|
|`POST` OpenClearDatasetItems|/open-api/ml_flow/v2/datasets/:datasetID/items/clear|清空草稿态数据行|
|`GET` OpenListDatasetItemsByVersion|/open-api/ml_flow/v2/datasets/:datasetID/versions/:versionID/items|固定版本的数据行列表|
|`GET` OpenListDatasetVersions|/open-api/ml_flow/v2/datasets/:datasetID/versions|获取数据集版本列表|
|`POST` OpenBatchCreateDatasetItems|/open-api/ml_flow/v2/datasets/:datasetID/items/batch|批量新增|
|`POST` OpenSearchDatasets|/open-api/ml_flow/v2/datasets/search|获取数据集列表|
|`GET` OpenGetDatasetIOJob|/open-api/ml_flow/v2/dataset_io_jobs/:jobID|任务(导入、导出、转换)详情|
|`POST` OpenImportDataset|/open-api/ml_flow/v2/datasets/:datasetID/import|导入数据|
|`POST` OpenExportDataset|/open-api/ml_flow/v2/datasets/:datasetID/export|导出数据|
|`PUT` OpenCancelDatasetIOJob|/open-api/ml_flow/v2/dataset_io_jobs/:jobID/cancel|取消一个任务|
|`GET` OpenGetAnnotationJobInstance|/open-api/ml_flow/v2/datasets/:datasetID/annotation_jobs/:jobID/instances|查看任务实例状态|
|`POST` OpenRunAnnotationJob|/open-api/ml_flow/v2/datasets/:datasetID/annotation_jobs/:jobID/run|运行任务|
|`GET` OpenListAnnotationJobs|/open-api/ml_flow/v2/datasets/:datasetID/annotation_jobs|列举数据集的标注任务|
|`POST` OpenTerminateAnnotationJob|/open-api/ml_flow/v2/datasets/:datasetID/annotation_jobs/:jobID/instances/:instanceID/terminate|终止标注任务|
|`POST` OpenCreateDataset|/open-api/ml_flow/v2/datasets|-|
<!-- bam-api END -->
