# 🕗 Change Log

## 1.2.8
>
> 2026-03-31

* [feat] update bam

## 1.2.7
>
> 2026-03-24

* [feat] update bam

## 1.2.6
>
> 2026-03-13

* [feat] add evaluator apis

## 1.2.5
>
> 2026-03-13

* [feat] add `skill-api`

## 1.2.4
>
> 2026-03-12

* [feat] update bam

## 1.2.3
>
> 2026-03-11

* [fix] missing params in `/v1/prompt/streaming_execute`

## 1.2.2
>
> 2026-03-05

* [feat] update bam

## 1.2.1
>
> 2026-02-09

* [feat] update bam

## 1.2.0
>
> 2026-02-03

* [feat] proxy and https agent

## 1.1.16
>
> 2026-02-03

* [feat] update bam
* [feat] mark `Blob` as `string`(base64) in BinaryContent
* [feat] update bam

## 1.1.15
>
> 2026-01-05

* [feat] update bam

## 1.1.14
>
> 2025-12-23

* [feat] update bam

## 1.1.13
>
> 2025-12-16

* [feat] add dataset annotation job apis

## 1.1.12
>
> 2025-12-11

* [feat] add dataset annotation job apis

## 1.1.11
>
> 2025-12-10

* [feat] update bam

## 1.1.10
>
> 2025-12-03

* [feat] update bam

## 1.1.9
>
> 2025-11-18

* [feat] add experiment apis

## 1.1.8
>
> 2025-11-17

* [fix] `I18N_DEV` region host

## 1.1.7
>
> 2025-11-17

* [feat] `I18N_DEV` region
* [feat] update bam

## 1.1.6
>
> 2025-10-29

* [fix] evaluation2-api types

## 1.1.5
>
> 2025-10-29

* [feat] add evaluation_sets apis in evaluation2-api

## 1.1.4
>
> 2025-10-29

* [feat] add evaluation2-api, `ReportEvalTargetInvokeResult`

## 1.1.3
>
> 2025-10-23

* [fix] fornax-api sub entry

## 1.1.2
>
> 2025-10-23

* [fix] readme

## 1.1.1
>
> 2025-10-23

* [feat] add span/trace apis
* [feat] add space apis
* [doc] open api doc links

## 1.1.0
>
> 2025-10-22

* [feat] update bam
* [feat] throw error in response

## 1.0.14
>
> 2025-09-30

* normal update

## 1.0.13
>
> 2025-09-26

* normal update
  * add dataset-api

## 1.0.12
>
> 2025-09-25

* normal update

## 1.0.11
>
> 2025-09-09

* normal update

## 1.0.10
>
> 2025-09-04

* normal update

## 1.0.9
>
> 2025-08-11

* normal update

## 1.0.8
>
> 2025-08-08

* Add supported regions: `I18N_VA` and `NON_TT`

## 1.0.7
>
> 2025-07-29

* normal update
  * observerability-api
  * evaluation-api: add 4 apis

## 1.0.6
>
> 2025-07-22

* normal update

## 1.0.5
>
> 2025-07-07

* normal update

## 1.0.4
>
> 2025-06-04

* normal update

## 1.0.3
>
> 2025-05-26

* normal update

## 1.0.2
>
> 2025-03-11

* normal update
  * knowledge-api: add 4 apis

## 1.0.1
>
> 2025-03-06

* normal update

## 1.0.0
>
> 2025-01-23

* Feature
  * prompt-api
  * knowledge-api
  * evaluation-api
