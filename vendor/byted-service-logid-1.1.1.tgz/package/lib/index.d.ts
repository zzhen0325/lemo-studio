import genLogID from './logid';
export * from './logid';
export default genLogID;
