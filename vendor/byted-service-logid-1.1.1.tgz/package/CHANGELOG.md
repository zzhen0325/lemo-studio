# CHANGELOG

[![bnpm](https://web-bnpm.byted.org/badge/v/@byted-service/logid.svg?style=flat-square)](https://web-bnpm.byted.org/package/@byted-service/logid) [![download](https://2y8ngapf.fn.bytedance.net/d?p=@byted-service/logid)](https://web-bnpm.byted.org/package/@byted-service/logid)

[简体中文](https://code.byted.org/nodejs/byted-service/blob/master/packages/logid/README.md) | [English](https://code.byted.org/nodejs/byted-service/blob/master/packages/logid/README.en.md) | [CHANGELOG](https://code.byted.org/nodejs/byted-service/blob/master/packages/logid/CHANGELOG.md)

## 1.1.1 

chore: update tslib version 
## 1.1.0

perf: 优化 lodId 生成，性能提升 3 倍

## 1.0.2

feat: 升级整体依赖版本

## 1.0.1

存在类型改动，跟随 @byted-service/rpc 发版

## 1.0.0

性能优化

```
generate logId (new) x 12,063,887 ops/sec ±0.92% (90 runs sampled)
generate logId (old) x 17,628 ops/sec ±0.86% (91 runs sampled)
Fastest is generate logId (new)
```

## 0.0.2

fix(logid): 修复 tslib 1.13.0 上，export \* from 不再对 export default 生效的问题
