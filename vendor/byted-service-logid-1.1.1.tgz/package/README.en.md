# logid

[![bnpm](https://web-bnpm.byted.org/badge/v/@byted-service/logid.svg?style=flat-square)](https://web-bnpm.byted.org/package/@byted-service/logid) [![download](https://2y8ngapf.fn.bytedance.net/d?p=@byted-service/logid)](https://web-bnpm.byted.org/package/@byted-service/logid)

[简体中文](https://code.byted.org/nodejs/byted-service/blob/master/packages/logid/README.md) | [English](https://code.byted.org/nodejs/byted-service/blob/master/packages/logid/README.en.md) | [CHANGELOG](https://code.byted.org/nodejs/byted-service/blob/master/packages/logid/CHANGELOG.md)

> [LogID IPV6 official specification](https://bytedance.feishu.cn/space/doc/doccnMHYlyOcMqEl56ujJC8IMQy#2YWBIX)

The logid module provides the function of generating logid based on IPv6 addresses

## Installation

```bash
npm install @byted-service/logid --registry=http://bnpm.byted.org
```

## Usage

```javascript
const genLogID = require('@byted-service/logid');
const logID = genLogID();
```
